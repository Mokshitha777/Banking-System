package database;

import java.util.List;
import java.util.Scanner;

public class BankingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccountDAO dao = new BankAccountDAO();

        while (true) {
            System.out.println("\n Banking System");
            System.out.println("1️ Add Bank Account");
            System.out.println("2️ View All Accounts");
            System.out.println("️3 Delete Account");
            System.out.println("4 Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (choice) {
                case 1:
                    System.out.print("Enter Account Holder Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Initial Balance: ");
                    double balance = scanner.nextDouble();
                    dao.addBankAccount(name, balance);
                    break;
                case 2:
                    List<BankAccount> accounts = dao.getAllAccounts();
                    for (BankAccount account : accounts) {
                        System.out.println(account);
                    }
                    break;
                case 3:
                	System.out.print("Enter Account ID to delete: ");
                	int deleteId=scanner.nextInt();
				BankAccountDAO bankDAO =new BankAccountDAO();
				bankDAO.deleteBankAccount(deleteId);
                	break;
                case 4:
                    System.out.println("✅ Exiting... Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("❌ Invalid choice! Try again.");
            }
        }
    }
}