package database;


public class BankAccount {
    private int accountId;
    private String accountHolderName;
    private double accountBalance;

    public BankAccount(int accountId, String accountHolderName, double accountBalance) {
        this.accountId = accountId;
        this.accountHolderName = accountHolderName;
        this.accountBalance = accountBalance;
    }

    public int getAccountId() {
        return accountId;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    @Override
    public String toString() {
        return "BankAccount{" +
               "accountId=" + accountId +
               ", accountHolderName='" + accountHolderName + '\'' +
               ", accountBalance=" + accountBalance +
               '}';
    }
}