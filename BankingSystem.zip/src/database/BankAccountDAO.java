package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BankAccountDAO {
    
    // Add a new bank account
    public void addBankAccount(String name, double balance) {
        String sql = "INSERT INTO BankAccount (account_holder_name, account_balance) VALUES (?, ?)";
        
        try (Connection conn = OracleDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, name);
            stmt.setDouble(2, balance);
            stmt.executeUpdate();
            System.out.println("✅ Bank account added successfully!");
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteBankAccount(int accountId) {
        String query = "DELETE FROM BankAccount WHERE account_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("✅ Account deleted successfully.");
            } else {
                System.out.println("⚠ No account found with the given ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private Connection getConnection() {
		// TODO Auto-generated method stub
		return null;
	}
	// Get all bank accounts
    public List<BankAccount> getAllAccounts() {
        List<BankAccount> accounts = new ArrayList<>();
        String sql = "SELECT * FROM BankAccount";

        try (Connection conn = OracleDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
             
            while (rs.next()) {
                accounts.add(new BankAccount(
                    rs.getInt("account_id"),
                    rs.getString("account_holder_name"),
                    rs.getDouble("account_balance")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return accounts;
    }
}